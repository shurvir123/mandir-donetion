CREATE DATABASE IF NOT EXISTS donation_db;
USE donation_db;

CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS donations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  donation_id VARCHAR(30) UNIQUE NOT NULL,
  donor_name VARCHAR(150) NOT NULL,
  email VARCHAR(255) NOT NULL,
  mobile VARCHAR(20),
  amount DECIMAL(12,2) NOT NULL,
  purpose VARCHAR(100) NOT NULL,
  utr VARCHAR(100) NOT NULL,
  payment_date DATE NOT NULL,
  screenshot_path VARCHAR(500),
  status ENUM('PENDING VERIFICATION','VERIFIED','REJECTED') NOT NULL DEFAULT 'PENDING VERIFICATION',
  certificate_number VARCHAR(40) UNIQUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  verified_at DATETIME NULL,
  rejected_at DATETIME NULL
);

-- The admin account is created by server.js on first run using .env values.
