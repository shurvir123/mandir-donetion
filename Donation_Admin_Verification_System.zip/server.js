require("dotenv").config();
const express = require("express");
const session = require("express-session");
const mysql = require("mysql2/promise");
const bcrypt = require("bcryptjs");
const nodemailer = require("nodemailer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(session({
  secret: process.env.SESSION_SECRET || "dev-secret-change-me",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly:true, sameSite:"lax", secure:false }
}));
app.use(express.static(path.join(__dirname,"public")));
app.use("/uploads", express.static(path.join(__dirname,"uploads")));

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "donation_db",
  waitForConnections:true,
  connectionLimit:10
});

function makeId(prefix) {
  return prefix + "-" + Date.now().toString(36).toUpperCase() + "-" +
    Math.random().toString(36).slice(2,7).toUpperCase();
}

async function init() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS admins (
      id INT AUTO_INCREMENT PRIMARY KEY,
      email VARCHAR(255) UNIQUE NOT NULL,
      password_hash VARCHAR(255) NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS donations (
      id INT AUTO_INCREMENT PRIMARY KEY,
      donation_id VARCHAR(30) UNIQUE NOT NULL,
      donor_name VARCHAR(150) NOT NULL,
      email VARCHAR(255) NOT NULL,
      mobile VARCHAR(20),
      amount DECIMAL(12,2) NOT NULL,
      purpose VARCHAR(100) NOT NULL,
      utr VARCHAR(100) NOT NULL,
      payment_date DATE NOT NULL,
      screenshot_path VARCHAR(500),
      status ENUM('PENDING VERIFICATION','VERIFIED','REJECTED') NOT NULL DEFAULT 'PENDING VERIFICATION',
      certificate_number VARCHAR(40) UNIQUE,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      verified_at DATETIME NULL,
      rejected_at DATETIME NULL
    )`);

  const [rows] = await pool.query("SELECT id FROM admins LIMIT 1");
  if (!rows.length) {
    const email = process.env.ADMIN_EMAIL || "admin@example.com";
    const password = process.env.ADMIN_PASSWORD || "ChangeMe123!";
    const hash = await bcrypt.hash(password, 12);
    await pool.query("INSERT INTO admins(email,password_hash) VALUES(?,?)",[email,hash]);
    console.log("Admin created:", email);
  }
}

function adminOnly(req,res,next) {
  if (!req.session.adminId) return res.status(401).json({error:"Admin login required"});
  next();
}

async function sendVerifiedEmail(donation) {
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 465),
    secure: String(process.env.SMTP_SECURE || "true") === "true",
    auth: { user:process.env.SMTP_USER, pass:process.env.SMTP_PASS }
  });

  const certificateUrl = `${process.env.PUBLIC_BASE_URL || `http://localhost:${PORT}`}/certificate/${donation.certificate_number}`;

  await transporter.sendMail({
    from: process.env.MAIL_FROM || process.env.SMTP_USER,
    to: donation.email,
    subject: "Donation Payment Verified - Thank You!",
    text:
`Dear ${donation.donor_name},

Your donation payment has been verified successfully.

Donation ID: ${donation.donation_id}
Amount: ₹${donation.amount}
Purpose: ${donation.purpose}
Payment Date: ${donation.payment_date}
Certificate Number: ${donation.certificate_number}

Your verified donation certificate is available here:
${certificateUrl}

Thank you for supporting our cause.

Raj Sarang`,
    html: `<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto">
      <h2 style="color:#6336c7">Thank You for Your Donation!</h2>
      <p>Dear <b>${escapeHtml(donation.donor_name)}</b>,</p>
      <p>Your donation payment has been <b style="color:green">VERIFIED</b> by the administrator.</p>
      <div style="padding:16px;background:#f5f3ff;border-radius:10px">
        <p><b>Donation ID:</b> ${escapeHtml(donation.donation_id)}</p>
        <p><b>Amount:</b> ₹${escapeHtml(String(donation.amount))}</p>
        <p><b>Purpose:</b> ${escapeHtml(donation.purpose)}</p>
        <p><b>Certificate No:</b> ${escapeHtml(donation.certificate_number)}</p>
      </div>
      <p><a href="${certificateUrl}" style="display:inline-block;background:#6336c7;color:white;padding:12px 18px;border-radius:8px;text-decoration:none">View Certificate</a></p>
      <p>Thank you for supporting our cause.</p><p>— Raj Sarang</p>
    </div>`
  });
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}

// Donor submits payment details. This NEVER verifies payment.
app.post("/api/donations", async (req,res) => {
  try {
    const {name,email,mobile,amount,purpose,utr,paymentDate} = req.body;
    if (!name || !email || !amount || !purpose || !utr || !paymentDate)
      return res.status(400).json({error:"Please fill all required fields."});
    if (!/^\d+(\.\d{1,2})?$/.test(String(amount)) || Number(amount) <= 0)
      return res.status(400).json({error:"Invalid donation amount."});
    if (!/^\d{10}$/.test(String(mobile || "")))
      return res.status(400).json({error:"Enter a valid 10-digit mobile number."});

    const donationId = makeId("DON");
    await pool.query(
      `INSERT INTO donations
      (donation_id,donor_name,email,mobile,amount,purpose,utr,payment_date)
      VALUES(?,?,?,?,?,?,?,?)`,
      [donationId,name.trim(),email.trim(),mobile,Number(amount),purpose,utr.trim(),paymentDate]
    );

    res.json({ok:true,donationId,status:"PENDING VERIFICATION",
      message:"Donation submitted. The admin will verify the UTR before confirming payment."});
  } catch(e) {
    console.error(e); res.status(500).json({error:"Server error"});
  }
});

// Admin login
app.post("/api/admin/login", async (req,res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM admins WHERE email=?",[req.body.email]);
    if (!rows.length || !(await bcrypt.compare(req.body.password,rows[0].password_hash)))
      return res.status(401).json({error:"Invalid admin credentials"});
    req.session.adminId = rows[0].id;
    res.json({ok:true});
  } catch(e){res.status(500).json({error:"Server error"});}
});

app.post("/api/admin/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));

app.get("/api/admin/donations",adminOnly,async(req,res)=>{
  const [rows]=await pool.query("SELECT * FROM donations ORDER BY created_at DESC");
  res.json(rows);
});

// Admin verifies the payment after checking UTR/screenshot in the bank/UPI records.
app.post("/api/admin/donations/:id/verify",adminOnly,async(req,res)=>{
  try{
    const [rows]=await pool.query("SELECT * FROM donations WHERE id=?",[req.params.id]);
    if(!rows.length)return res.status(404).json({error:"Donation not found"});
    const d=rows[0];
    if(d.status==="VERIFIED")return res.json({ok:true,message:"Already verified"});
    const cert=makeId("CERT");
    await pool.query(
      `UPDATE donations SET status='VERIFIED',certificate_number=?,verified_at=NOW() WHERE id=?`,
      [cert,d.id]
    );
    d.status="VERIFIED"; d.certificate_number=cert;
    let emailSent=true;
    try { await sendVerifiedEmail(d); }
    catch(err){ emailSent=false; console.error("Email failed:",err.message); }
    res.json({ok:true,emailSent,certificateNumber:cert,
      message:emailSent ? "Payment verified and donor notification sent." :
      "Payment verified, but donor email could not be sent. Check SMTP settings."});
  }catch(e){console.error(e);res.status(500).json({error:"Server error"});}
});

app.post("/api/admin/donations/:id/reject",adminOnly,async(req,res)=>{
  await pool.query("UPDATE donations SET status='REJECTED',rejected_at=NOW() WHERE id=?",[req.params.id]);
  res.json({ok:true});
});

// Public certificate page — only safe fields.
app.get("/certificate/:cert",(req,res)=>{
  res.sendFile(path.join(__dirname,"public","certificate.html"));
});

app.get("/api/certificate/:cert",async(req,res)=>{
  const [rows]=await pool.query(
    `SELECT certificate_number,donor_name,amount,payment_date,donation_id,status,purpose
     FROM donations WHERE certificate_number=? AND status='VERIFIED'`,[req.params.cert]);
  if(!rows.length)return res.status(404).json({error:"Certificate not found or not verified"});
  res.json(rows[0]);
});

init().then(()=>app.listen(PORT,()=>console.log(`http://localhost:${PORT}`)))
.catch(e=>{console.error(e);process.exit(1)});
