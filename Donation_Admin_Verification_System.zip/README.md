# Donation Admin Verification System

## What happens
1. Donor scans the supplied QR and pays.
2. Donor submits name, email, amount and UTR.
3. Donation is saved as `PENDING VERIFICATION`.
4. Admin logs in at `/admin.html`.
5. Admin checks the UTR/payment in the actual UPI/bank records.
6. Admin clicks **Verify Payment**.
7. Status changes to `VERIFIED`.
8. The server generates a certificate number.
9. The donor receives an email saying **Your donation payment has been verified** with a certificate link.
10. The public certificate page shows only safe donation information.

## Setup
1. Install Node.js and MySQL.
2. Create the database using `database.sql`.
3. Copy `.env.example` to `.env` and fill in MySQL + SMTP values.
4. Run:
   `npm install`
   `npm start`
5. Open `http://localhost:3000`
6. Admin: `http://localhost:3000/admin.html`

## Gmail
For Gmail SMTP, use a Google App Password rather than your normal Gmail password. Enable 2-Step Verification on the sending Gmail account, then create an App Password.

## Important
The website does NOT treat a donor's screenshot/UTR submission as proof of payment. Only an authenticated admin can change the status to VERIFIED. The donor email is sent only after that admin verification action.

For production, use HTTPS, secure cookies, rate limiting, CSRF protection, virus scanning for uploads, and a real payment gateway/API if automatic payment verification is required.
